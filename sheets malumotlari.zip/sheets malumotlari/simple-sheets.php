<?php
// Konfiguratsiya
$spreadsheetId = 'YOUR_SPREADSHEET_ID'; // Google Sheets ID
$credentialsFile = __DIR__ . '/credentials.json'; // Credentials fayl yo'li

// Forma yuborilganini tekshirish
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Formadan kelgan ma'lumotlarni olish
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $message = $_POST['message'] ?? '';
    
    // Ma'lumotlarni Google Sheets ga yozish
    $result = appendToSheet($name, $email, $message);
    
    if ($result) {
        $success = "Ma'lumotlar muvaffaqiyatli saqlandi!";
    } else {
        $error = "Xatolik yuz berdi. Iltimos, qaytadan urinib ko'ring.";
    }
}

/**
 * Ma'lumotlarni Google Sheets ga yozish
 */
function appendToSheet($name, $email, $message) {
    global $spreadsheetId, $credentialsFile;
    
    try {
        // Credentials faylini o'qish
        $credentials = json_decode(file_get_contents($credentialsFile), true);
        
        // Service account ma'lumotlari
        $client_email = $credentials['client_email'];
        $private_key = $credentials['private_key'];
        
        // JWT token yaratish
        $jwt = createJWT($client_email, $private_key);
        
        // Access token olish
        $accessToken = getAccessToken($jwt);
        
        if (!$accessToken) {
            return false;
        }
        
        // Ma'lumotlarni tayyorlash
        $values = [
            [$name, $email, $message, date('Y-m-d H:i:s')]
        ];
        
        $body = json_encode([
            'values' => $values
        ]);
        
        // Google Sheets API ga so'rov yuborish
        $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheetId}/values/Sheet1!A:D:append?valueInputOption=RAW";
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json'
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return ($httpCode >= 200 && $httpCode < 300);
    } catch (Exception $e) {
        error_log('Google Sheets xatosi: ' . $e->getMessage());
        return false;
    }
}

/**
 * JWT token yaratish
 */
function createJWT($client_email, $private_key) {
    $header = json_encode([
        'alg' => 'RS256',
        'typ' => 'JWT'
    ]);
    
    $time = time();
    $payload = json_encode([
        'iss' => $client_email,
        'scope' => 'https://www.googleapis.com/auth/spreadsheets',
        'aud' => 'https://oauth2.googleapis.com/token',
        'exp' => $time + 3600,
        'iat' => $time
    ]);
    
    $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
    $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
    
    $signatureInput = $base64Header . '.' . $base64Payload;
    
    $signature = '';
    openssl_sign($signatureInput, $signature, $private_key, 'SHA256');
    $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
    
    return $base64Header . '.' . $base64Payload . '.' . $base64Signature;
}

/**
 * Access token olish
 */
function getAccessToken($jwt) {
    $url = 'https://oauth2.googleapis.com/token';
    
    $data = [
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion' => $jwt
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode >= 200 && $httpCode < 300) {
        $responseData = json_decode($response, true);
        return $responseData['access_token'] ?? null;
    }
    
    return null;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Google Sheets ga ma'lumot yozish</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input, textarea {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
        }
        .success {
            color: green;
            margin-bottom: 15px;
        }
        .error {
            color: red;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <h1>Google Sheets ga ma'lumot yozish</h1>
    
    <?php if (isset($success)): ?>
        <div class="success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if (isset($error)): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <form method="post">
        <div class="form-group">
            <label for="name">Ism:</label>
            <input type="text" id="name" name="name" required>
        </div>
        
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        
        <div class="form-group">
            <label for="message">Xabar:</label>
            <textarea id="message" name="message" rows="4" required></textarea>
        </div>
        
        <button type="submit">Yuborish</button>
    </form>
</body>
</html>
