<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - ' . SITE_NAME : SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="site-header">
        <div class="container">
            <div class="logo">
                <a href="index.php">
                    <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>" width="150">
                </a>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Bosh sahifa</a></li>
                    <li><a href="form.php">Forma</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <main class="site-content">
        <div class="container">
