// Forma tekshirish
document.addEventListener("DOMContentLoaded", () => {
  const dataForm = document.querySelector(".data-form")

  if (dataForm) {
    dataForm.addEventListener("submit", (event) => {
      let isValid = true

      // Ism tekshirish
      const nameInput = document.getElementById("name")
      if (!nameInput.value.trim()) {
        showError(nameInput, "Iltimos, ismingizni kiriting")
        isValid = false
      } else {
        removeError(nameInput)
      }

      // Email tekshirish
      const emailInput = document.getElementById("email")
      if (!emailInput.value.trim()) {
        showError(emailInput, "Iltimos, emailingizni kiriting")
        isValid = false
      } else if (!isValidEmail(emailInput.value)) {
        showError(emailInput, "Iltimos, to'g'ri email manzilini kiriting")
        isValid = false
      } else {
        removeError(emailInput)
      }

      // Xabar tekshirish
      const messageInput = document.getElementById("message")
      if (!messageInput.value.trim()) {
        showError(messageInput, "Iltimos, xabar kiriting")
        isValid = false
      } else {
        removeError(messageInput)
      }

      if (!isValid) {
        event.preventDefault()
      }
    })
  }

  // Email validatsiyasi
  function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  // Xatolikni ko'rsatish
  function showError(input, message) {
    const formGroup = input.closest(".form-group")
    const errorElement = formGroup.querySelector(".error-message")

    if (!errorElement) {
      const error = document.createElement("div")
      error.className = "error-message"
      error.textContent = message
      formGroup.appendChild(error)
    } else {
      errorElement.textContent = message
    }

    input.classList.add("error-input")
  }

  // Xatolikni o'chirish
  function removeError(input) {
    const formGroup = input.closest(".form-group")
    const errorElement = formGroup.querySelector(".error-message")

    if (errorElement) {
      errorElement.remove()
    }

    input.classList.remove("error-input")
  }
})
