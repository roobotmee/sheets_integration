<?php
// Xatoliklarni ko'rsatish (muammolarni aniqlash uchun)
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

// Xatoliklarni faylga yozish
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Sessiyani boshlash
session_start();

// Konfiguratsiya
$spreadsheetId = '16E-5six5nn1Vn0j9wni1Hk0v2EWtoCp0a6u8XnHCbhw'; // Google Sheets jadval ID si
$sheetName = 'Sheet1'; // Google Sheets varaq nomi
$credentialsFile = __DIR__ . '/credentials.json'; // Credentials fayl yo'li

// Xabarlar
$success = $error = '';

// Forma yuborilganini tekshirish
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Formadan kelgan ma'lumotlarni olish va tozalash
    $name = isset($_POST['name']) ? trim(htmlspecialchars($_POST['name'])) : '';
    $email = isset($_POST['email']) ? trim(htmlspecialchars($_POST['email'])) : '';
    $phone = isset($_POST['phone']) ? trim(htmlspecialchars($_POST['phone'])) : '';
    $message = isset($_POST['message']) ? trim(htmlspecialchars($_POST['message'])) : '';
    
    // Ma'lumotlarni tekshirish
    $errors = [];
    
    if (empty($name)) {
        $errors[] = 'Ism kiritilmagan';
    }
    
    if (empty($email)) {
        $errors[] = 'Email kiritilmagan';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email formati noto\'g\'ri';
    }
    
    if (empty($message)) {
        $errors[] = 'Xabar kiritilmagan';
    }
    
    // Xatolik bo'lmasa, ma'lumotlarni Google Sheets ga yozish
    if (empty($errors)) {
        // Ma'lumotlarni tayyorlash
        $data = [
            $name,
            $email,
            $phone,
            $message,
            date('Y-m-d H:i:s')
        ];
        
        // Google Sheets ga yozish
        $result = appendToSheet($data);
        
        if ($result === true) {
            $success = 'Ma\'lumotlar muvaffaqiyatli yuborildi!';
            // Formani tozalash
            $name = $email = $phone = $message = '';
        } else {
            $error = 'Ma\'lumotlarni yuborishda xatolik yuz berdi: ' . $result;
            error_log('Google Sheets xatolik: ' . $result);
        }
    } else {
        $error = implode('<br>', $errors);
    }
}

/**
 * Ma'lumotlarni Google Sheets ga yozish
 */
function appendToSheet($data) {
    global $spreadsheetId, $sheetName, $credentialsFile;
    
    try {
        // Credentials faylini o'qish
        if (!file_exists($credentialsFile)) {
            return "Credentials fayli topilmadi: " . $credentialsFile;
        }
        
        $credentials = json_decode(file_get_contents($credentialsFile), true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return "Credentials faylini o'qishda xatolik: " . json_last_error_msg();
        }
        
        // Service account ma'lumotlari
        $client_email = $credentials['client_email'];
        $private_key = $credentials['private_key'];
        
        // JWT token yaratish
        $jwt = createJWT($client_email, $private_key);
        
        // Access token olish
        $accessToken = getAccessToken($jwt);
        
        if (!$accessToken) {
            return "Access token olishda xatolik";
        }
        
        // Ma'lumotlarni tayyorlash
        $values = [$data];
        
        $body = json_encode([
            'values' => $values
        ]);
        
        // Google Sheets API ga so'rov yuborish
        $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheetId}/values/{$sheetName}!A:Z:append?valueInputOption=RAW";
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json'
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch)) {
            $error = "cURL xatolik: " . curl_error($ch);
            curl_close($ch);
            return $error;
        }
        
        curl_close($ch);
        
        if ($httpCode < 200 || $httpCode >= 300) {
            return "Google Sheets API xatolik: HTTP " . $httpCode . " - " . $response;
        }
        
        return true;
    } catch (Exception $e) {
        return "Google Sheets xatosi: " . $e->getMessage();
    }
}

/**
 * JWT token yaratish
 */
function createJWT($client_email, $private_key) {
    $header = json_encode([
        'alg' => 'RS256',
        'typ' => 'JWT'
    ]);
    
    $time = time();
    $payload = json_encode([
        'iss' => $client_email,
        'scope' => 'https://www.googleapis.com/auth/spreadsheets',
        'aud' => 'https://oauth2.googleapis.com/token',
        'exp' => $time + 3600,
        'iat' => $time
    ]);
    
    $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
    $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
    
    $signatureInput = $base64Header . '.' . $base64Payload;
    
    $signature = '';
    openssl_sign($signatureInput, $signature, $private_key, 'SHA256');
    $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
    
    return $base64Header . '.' . $base64Payload . '.' . $base64Signature;
}

/**
 * Access token olish
 */
function getAccessToken($jwt) {
    $url = 'https://oauth2.googleapis.com/token';
    
    $data = [
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion' => $jwt
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode >= 200 && $httpCode < 300) {
        $responseData = json_decode($response, true);
        return $responseData['access_token'] ?? null;
    }
    
    return null;
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ma'lumotlarni yuborish - SOSSMM.UZ</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f9f9f9;
            padding: 20px;
        }
        
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        h1 {
            margin-bottom: 20px;
            color: #2e7d32;
            text-align: center;
        }
        
        p {
            margin-bottom: 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        input, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }
        
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        
        button {
            display: inline-block;
            background-color: #4caf50;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
        }
        
        button:hover {
            background-color: #2e7d32;
        }
        
        .success {
            background-color: #e8f5e9;
            color: #2e7d32;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .error {
            background-color: #ffebee;
            color: #c62828;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .site-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .site-header img {
            max-width: 200px;
            height: auto;
        }
        
        .site-footer {
            text-align: center;
            margin-top: 30px;
            color: #777;
            font-size: 0.9rem;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="site-header">
            <h1>SOSSMM.UZ</h1>
            <p>Ma'lumotlarni yuborish formasi</p>
        </div>
        
        <?php if (!empty($success)): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (!empty($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="post" action="">
            <div class="form-group">
                <label for="name">Ism:</label>
                <input type="text" id="name" name="name" value="<?php echo isset($name) ? htmlspecialchars($name) : ''; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="phone">Telefon:</label>
                <input type="tel" id="phone" name="phone" value="<?php echo isset($phone) ? htmlspecialchars($phone) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="message">Xabar:</label>
                <textarea id="message" name="message" required><?php echo isset($message) ? htmlspecialchars($message) : ''; ?></textarea>
            </div>
            
            <button type="submit">Yuborish</button>
        </form>
        
        <div class="site-footer">
            <p>&copy; <?php echo date('Y'); ?> SOSSMM.UZ. Barcha huquqlar himoyalangan.</p>
        </div>
    </div>
    
    <script>
        // Forma tekshirish
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            
            form.addEventListener('submit', function(event) {
                let isValid = true;
                
                // Ism tekshirish
                const nameInput = document.getElementById('name');
                if (!nameInput.value.trim()) {
                    isValid = false;
                    nameInput.style.borderColor = 'red';
                } else {
                    nameInput.style.borderColor = '';
                }
                
                // Email tekshirish
                const emailInput = document.getElementById('email');
                if (!emailInput.value.trim()) {
                    isValid = false;
                    emailInput.style.borderColor = 'red';
                } else if (!isValidEmail(emailInput.value)) {
                    isValid = false;
                    emailInput.style.borderColor = 'red';
                } else {
                    emailInput.style.borderColor = '';
                }
                
                // Xabar tekshirish
                const messageInput = document.getElementById('message');
                if (!messageInput.value.trim()) {
                    isValid = false;
                    messageInput.style.borderColor = 'red';
                } else {
                    messageInput.style.borderColor = '';
                }
                
                if (!isValid) {
                    event.preventDefault();
                }
            });
            
            // Email validatsiyasi
            function isValidEmail(email) {
                const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return regex.test(email);
            }
        });
    </script>
</body>
</html>
