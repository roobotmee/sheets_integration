<?php
require_once 'config.php';

$pageTitle = 'Ma\'lumot yuborish';
require_once 'includes/header.php';
?>

<div class="form-section">
    <h1>Ma'lumotlarni yuborish</h1>
    <p>Iltimos, quyidagi formani to'ldiring. Ma'lumotlar Google Sheets jadvaliga yuboriladi.</p>
    
    <form action="process.php" method="post" class="data-form">
        <div class="form-group">
            <label for="name">Ism:</label>
            <input type="text" id="name" name="name" required>
        </div>
        
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        
        <div class="form-group">
            <label for="phone">Telefon:</label>
            <input type="tel" id="phone" name="phone">
        </div>
        
        <div class="form-group">
            <label for="message">Xabar:</label>
            <textarea id="message" name="message" rows="4" required></textarea>
        </div>
        
        <div class="form-group">
            <button type="submit" class="submit-button">Yuborish</button>
        </div>
    </form>
</div>

<?php require_once 'includes/footer.php'; ?>
