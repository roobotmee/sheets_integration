<?php
require_once 'config.php';
require_once 'includes/functions.php';
require_once 'sheets.php';

// Xatolik va muvaffaqiyat xabarlarini saqlash uchun sessiyani boshlash
session_start();

// POST so'rovi kelganini tekshirish
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Formadan kelgan ma'lumotlarni olish va tozalash
    $name = isset($_POST['name']) ? sanitize($_POST['name']) : '';
    $email = isset($_POST['email']) ? sanitize($_POST['email']) : '';
    $phone = isset($_POST['phone']) ? sanitize($_POST['phone']) : '';
    $message = isset($_POST['message']) ? sanitize($_POST['message']) : '';
    
    // Ma'lumotlarni tekshirish
    $errors = [];
    
    if (empty($name)) {
        $errors[] = 'Ism kiritilmagan';
    }
    
    if (empty($email)) {
        $errors[] = 'Email kiritilmagan';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email formati noto\'g\'ri';
    }
    
    if (empty($message)) {
        $errors[] = 'Xabar kiritilmagan';
    }
    
    // Xatolik bo'lmasa, ma'lumotlarni Google Sheets ga yozish
    if (empty($errors)) {
        // Ma'lumotlarni tayyorlash
        $data = [
            $name,
            $email,
            $phone,
            $message,
            date('Y-m-d H:i:s')
        ];
        
        // Google Sheets ga yozish
        $result = appendToSheet($data);
        
        if ($result) {
            $_SESSION['success'] = 'Ma\'lumotlar muvaffaqiyatli yuborildi!';
            header('Location: success.php');
            exit;
        } else {
            $_SESSION['error'] = 'Ma\'lumotlarni yuborishda xatolik yuz berdi. Iltimos, qaytadan urinib ko\'ring.';
            header('Location: form.php');
            exit;
        }
    } else {
        // Xatoliklar bo'lsa, ularni sessiyaga saqlash va formaga qaytarish
        $_SESSION['errors'] = $errors;
        header('Location: form.php');
        exit;
    }
} else {
    // POST so'rovi bo'lmasa, bosh sahifaga yo'naltirish
    header('Location: index.php');
    exit;
}
