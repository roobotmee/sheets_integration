<?php
require_once 'config.php';

// Sessiyani boshlash
session_start();

// Muvaffaqiyat xabari bo'lmasa, bosh sahifaga yo'naltirish
if (!isset($_SESSION['success'])) {
    header('Location: index.php');
    exit;
}

$success = $_SESSION['success'];
unset($_SESSION['success']);

$pageTitle = 'Muvaffaqiyatli yuborildi';
require_once 'includes/header.php';
?>

<div class="success-section">
    <div class="success-message">
        <h1>Muvaffaqiyatli yuborildi!</h1>
        <p><?php echo $success; ?></p>
        <div class="cta-button">
            <a href="index.php" class="button">Bosh sahifaga qaytish</a>
            <a href="form.php" class="button button-secondary">Yana ma'lumot yuborish</a>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
