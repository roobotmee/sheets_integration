</div>
    </main>
    <footer class="site-footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. Barcha huquqlar himoyalangan.</p>
        </div>
    </footer>
    <script src="assets/js/script.js"></script>
</body>
</html>
