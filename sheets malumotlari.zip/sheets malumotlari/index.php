<?php
// Asosiy sahifa - google-sheets-form.php ga yo'naltirish
header("Location: google-sheets-form.php");
exit;
?>
