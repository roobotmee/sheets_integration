"use client"

import  from "../assets/js/script"

export default function SyntheticV0PageForDeployment() {
  return < />
}