<?php
// Google Sheets API konfiguratsiyasi
define('SPREADSHEET_ID', 'YOUR_SPREADSHEET_ID'); // Google Sheets jadval ID si
define('SHEET_NAME', 'Sheet1'); // Google Sheets varaq nomi
define('CREDENTIALS_PATH', __DIR__ . '/credentials.json'); // Credentials fayl yo'li

// Sayt konfiguratsiyasi
define('SITE_NAME', 'Sayt Nomi');
define('SITE_URL', 'https://sossmm.uz');
define('ADMIN_EMAIL', 'admin@example.com');

// Xatoliklarni ko'rsatish (ishlab chiqish rejimida)
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
