<?php
require_once 'config.php';
require_once 'includes/functions.php';

/**
 * Ma'lumotlarni Google Sheets ga yozish
 */
function appendToSheet($data) {
    try {
        // Credentials faylini o'qish
        if (!file_exists(CREDENTIALS_PATH)) {
            logError('Credentials fayli topilmadi: ' . CREDENTIALS_PATH);
            return false;
        }
        
        $credentials = json_decode(file_get_contents(CREDENTIALS_PATH), true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            logError('Credentials faylini o\'qishda xatolik: ' . json_last_error_msg());
            return false;
        }
        
        // Service account ma'lumotlari
        $client_email = $credentials['client_email'];
        $private_key = $credentials['private_key'];
        
        // JWT token yaratish
        $jwt = createJWT($client_email, $private_key);
        
        // Access token olish
        $accessToken = getAccessToken($jwt);
        
        if (!$accessToken) {
            logError('Access token olishda xatolik');
            return false;
        }
        
        // Ma'lumotlarni tayyorlash
        $values = [$data];
        
        $body = json_encode([
            'values' => $values
        ]);
        
        // Google Sheets API ga so'rov yuborish
        $url = "https://sheets.googleapis.com/v4/spreadsheets/" . SPREADSHEET_ID . "/values/" . SHEET_NAME . "!A:Z:append?valueInputOption=RAW";
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json'
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch)) {
            logError('cURL xatolik: ' . curl_error($ch));
            curl_close($ch);
            return false;
        }
        
        curl_close($ch);
        
        if ($httpCode < 200 || $httpCode >= 300) {
            logError('Google Sheets API xatolik: HTTP ' . $httpCode . ' - ' . $response);
            return false;
        }
        
        return true;
    } catch (Exception $e) {
        logError('Google Sheets xatosi: ' . $e->getMessage());
        return false;
    }
}
